create database LibraryManagementSystems;
#use LibraryManagementSystems;
#drop database LibraryManagementSystems;

CREATE TABLE author (
  author_name varchar(64) NOT NULL,
  author_id int(11) NOT NULL,
  primary key (author_id)
);

drop table author;

INSERT INTO `author` (`author_name`, `author_id`) VALUES
('David Schwartz', 1101),
('Peter Thiel', 1102),
('Leil Lownd', 1103),
('Robert Kiosaky', 1104),
('Rolf Dobelli', 1105),
('Bill Bryson', 1106),
('J.R.R. Tolkien', 1107),
('Jude Fisher', 1108),
('Dave Thomas', 1109),
('Gary Paulsen', 1110);

CREATE TABLE members (
  id int(11) NOT NULL,
  city varchar(32) NOT NULL,
  zip int(11) NOT NULL,
  street varchar(64) NOT NULL,
  first_name varchar(32) NOT NULL,
  middle_name varchar(32) DEFAULT NULL,
  last_name varchar(32) NOT NULL,
  type varchar(7) NOT NULL,
  date_of_birth date NOT NULL,
  gender varchar(8) NOT NULL,
  primary key (id, type)
);

drop table members;

INSERT INTO `members` (`id`, `city`, `zip`, `street`, `first_name`, `middle_name`, `last_name`, `type`, `date_of_birth`, `gender`) VALUES
(101, 'Dhaka North', 1361, '18/61, Bamoil Purba para', 'Mizanur', 'Rahman', 'Riad Khan', 'Student', '1999-05-17', 'Male'),
(102, 'Dhaka North', 1361, 'Hazinagar', 'Touhidul', 'Hoque', 'Shagor', 'Student', '1998-10-26', 'Male'),
(103, 'Dhaka North', 1202, '125 Cresent Road', 'Maimoon', 'Hossain', 'Shomoy', 'Student', '1980-06-21', 'Male'),
(104, 'Dhaka', 1100, 'Aftabnagar', 'Mostafa', 'Kamal', 'Rasel', 'Faculty', '1980-06-21', 'Male'),
(105, 'Dhaka South', 1300, 'A/2, Aftabnagar Dhaka', 'Md', '', 'Al-Imran', 'Faculty', '1995-12-15', 'Male'),
(106, 'Dhaka South', 1221, 'East West Road', 'Maheen', '', 'Islam', 'Faculty', '1985-01-23', 'Female'),
(107, 'Dhaka', 1031, 'Puran Dhaka', 'Masiath', '', 'Mubasshira', 'Faculty', '1995-09-10', 'Female'),
(108, 'Dhaka South', 1203, '18/61 Zhigatola', 'Sobhani', 'Fahim', 'Khan', 'Student', '1999-05-25', 'Male'),
(109, 'Dhaka South', 1260, '120 Hazaribag', 'Amit', 'Hasan', 'Shorkar', 'Student', '1998-11-26', 'Male'),
(110, 'Dhaka North', 1202, '125 Cresent Road', 'Sagor', 'Hossain', 'Khalek', 'Student', '1997-06-21', 'Male'),
(111, 'Dhaka', 1100, '107 Aftabnagar', 'Mostafa', 'Duran', 'Rafid', 'Faculty', '1980-06-16', 'Male'),
(112, 'Dhaka South', 1300, 'A/2 Aftabnagar Dhaka', 'Dr.', 'Md', 'Wasif', 'Faculty', '1982-12-15', 'Male'),
(113, 'Dhaka South', 1221, 'C/3 East West Road', 'Mozammel', 'Huq', 'Azad', 'Faculty', '1986-01-23', 'Male'),
(114, 'Dhaka', 1031, '13/60 Puran Dhaka', 'Md', 'Ruhul', 'Amin', 'Faculty', '1979-09-10', 'Male'),
(115, 'Dhaka', 1200, '16/65 Dhanmondi', 'Rajia', '', 'Sultana', 'Faculty', '1981-09-10', 'Female');



CREATE TABLE members_phone_number (
  phone_number varchar(15) NOT NULL,
  id int(11) NOT NULL,
  type varchar(7) NOT NULL,
  primary key (phone_number),
  Foreign key(id, type) references members(id, type)
);

INSERT INTO `members_phone_number` (`phone_number`, `id`, `type`) VALUES
('8801611495201', 101, 'Student'),
('8801990788072', 101, 'Student'),
('8801521719868', 102, 'Student'),
('8801825954608', 103, 'Student'),
('8801856740543', 104, 'Faculty'),
('8801609209057', 105, 'Faculty'),
('8801609209058', 106, 'Faculty'),
('8801611495200', 107, 'Faculty'),
('8801790788072', 108, 'Student'),
('8801790788073', 108, 'Student'),
('8801621719865', 109, 'Student'),
('8801925954606', 110, 'Student'),
('8801756740544', 111, 'Faculty'),
('8801509209059', 112, 'Faculty'),
('8801809209057', 113, 'Faculty'),
('8801811495206', 114, 'Faculty'),
('8801711495205', 115, 'Faculty');

CREATE TABLE book (
  book_code int NOT NULL,
  book_title varchar(128) NOT NULL,
  category varchar(64) NOT NULL,
  publication varchar(64) NOT NULL,
  publish_date date NOT NULL,
  book_edition varchar(16) NOT NULL,
  price float NOT NULL,
  quantity int NOT NULL,
  primary key (book_code, book_title)
);


INSERT INTO `book` (`book_code`, `book_title`, `category`, `publication`, `publish_date`, `book_edition`, `price`, `quantity`) VALUES
(1001, 'Mein Kamf', 'crime', 'Pyie and Page', '1938-03-08', '2nd Edi.', 220.5, 10),
(1002, 'Zero To One', 'business', 'Schildt', '2000-03-08', '4th Edi.', 300, 5),
(1003, 'Rich and Poor', 'Strategy', 'Gill', '1978-03-08', '6th Edi.', 400, 15),
(1004, 'The Secret', 'Fictional', 'Agroni', '2015-03-08', '1st Edi.', 550, 12),
(1005, 'Think and Grow Rich', 'Philosophy', 'Norman', '1920-03-08', '5th Edi.', 600, 20),
(1006, 'The Hitchhiker\'s Guide to the Galaxy', 'Philosophy', 'iBooks', '1948-03-08', '2nd Edi.', 420.5, 13),
(1007, 'In a Sunburned Country', 'Strategy', 'Barnes & Noble Press', '2010-03-08', '4th Edi.', 270, 7),
(1008, 'Notes from a Small Island', 'business', 'Smashwords', '1998-03-08', '6th Edi.', 450, 18),
(1009, 'The Mother Tongue', 'Fictional', 'IngramSpark', '2005-03-08', '1st Edi.', 550, 20),
(1010, 'The Lord of the Rings', 'crime', 'CreateSpace', '1940-03-08', '5th Edi.', 750, 25);

CREATE TABLE book_issue (
  date_issue date NOT NULL,
  date_return date NOT NULL,
  date_returned date NOT NULL,
  book_issue_status varchar(16) NOT NULL,
  book_code int NOT NULL,
  book_title varchar(128) NOT NULL,
  id int NOT NULL,
  limitation int NOT NULL,
  type varchar(7) NOT NULL,
  Foreign key(book_code, book_title) references book(book_code, book_title),
  Foreign key(id, type) references members(id, type)
);

drop table book_issue;

INSERT INTO `book_issue` (`date_issue`, `date_return`, `date_returned`, `book_issue_status`, `book_code`, `book_title`, `id`,`limitation`,`type`) VALUES
('2021-12-10', '2021-12-19', '2021-12-18', 'Returned', 1001, 'Mein Kamf', 101,4, 'Student'),
('2019-12-10', '2019-12-16', '2019-12-19', 'Late Returned', 1001, 'Mein Kamf', 104, 5,'Faculty'),
('2022-02-21', '2023-03-02', '0000-00-00', 'Not Returned', 1001, 'Mein Kamf', 106, 5, 'Faculty'),
('2021-11-15', '2021-11-21', '0000-00-00', 'Not Returned', 1002, 'Zero To One', 102, 4,'Student'),
('2022-11-15', '2022-11-21', '0000-00-00', 'Not Returned', 1002, 'Zero To One', 112,5,'Faculty'),
('2021-12-10', '2021-12-19', '2021-12-18', 'Returned', 1003, 'Rich and Poor', 101, 4, 'Student'),
('2022-01-02', '2021-01-08', '0000-00-00', 'Not Returned', 1003, 'Rich and Poor', 103, 4,'Student'),
('2021-01-01', '2021-01-09', '2021-01-11', 'Late Returned', 1004, 'The Secret', 104, 5,'Faculty'),
('2021-10-12', '2021-10-21', '2021-10-30', 'Late Returned', 1005, 'Think and Grow Rich', 105, 5,'Faculty'),
('2022-12-10', '2022-12-19', '2022-12-18', 'Returned', 1007, 'In a Sunburned Country', 111, 5,'Faculty'),
('2022-01-01', '2022-01-09', '2022-01-11', 'Late Returned', 1008, 'Notes from a Small Island', 110, 4,'Student'),
('2022-02-21', '2023-03-02', '0000-00-00', 'Not Returned', 1009, 'The Mother Tongue', 114, 4,'Faculty'),
('2022-12-10', '2022-12-16', '2022-12-19', 'Late Returned', 1010, 'The Lord of the Rings', 115, 5, 'Faculty');

select * from book_issue;
CREATE TABLE has(
  author_id int NOT NULL,
  book_code int NOT NULL,
  book_title varchar(128) NOT NULL,
  Foreign key(book_code, book_title) references book(book_code, book_title),
  Foreign key(author_id) references author(author_id)
);

INSERT INTO `has` (`author_id`, `book_code`, `book_title`) VALUES
(1101, 1001, 'Mein Kamf'),
(1102, 1002, 'Zero To One'),
(1103, 1003, 'Rich and Poor'),
(1104, 1004, 'The Secret'),
(1105, 1005, 'Think and Grow Rich'),
(1106, 1006, 'The Hitchhiker\'s Guide to the Galaxy'),
(1107, 1007, 'In a Sunburned Country'),
(1108, 1008, 'Notes from a Small Island'),
(1109, 1009, 'The Mother Tongue'),
(1110, 1010, 'The Lord of the Rings');


CREATE TABLE issued_by (
   book_code int NOT NULL,
   book_title varchar(128) NOT NULL,
   id int NOT NULL,
   type varchar(7) NOT NULL,
   Foreign key(book_code, book_title) references book(book_code, book_title),
   Foreign key(id, type) references members(id, type)
);

INSERT INTO `issued_by` (`book_code`, `book_title`, `id`, `type`) VALUES
(1001, 'Mein Kamf', 101, 'Student'),
(1001, 'Mein Kamf', 106, 'Faculty'),
(1002, 'Zero To One', 102, 'Student'),
(1002, 'Zero To One', 112, 'Faculty'),
(1003, 'Rich and Poor', 101, 'Student'),
(1003, 'Rich and Poor', 103, 'Student'),
(1004, 'The Secret', 104, 'Faculty'),
(1005, 'Think and Grow Rich', 105, 'Faculty'),
(1007, 'In a Sunburned Country', 111, 'Faculty'),
(1008, 'Notes from a Small Island', 110, 'Student'),
(1009, 'The Mother Tongue', 114, 'Faculty'),
(1010, 'The Lord of the Rings', 115, 'Faculty');

CREATE TABLE fine (
  fine_amount float NOT NULL,
  fine_status varchar(6) NOT NULL,
  id int NOT NULL,
  type varchar(7) NOT NULL,
  book_code int NOT NULL,
  book_title varchar(128) NOT NULL,
  Foreign key(book_code, book_title) references book(book_code, book_title),
  Foreign key(id, type) references members(id, type)
);

INSERT INTO `fine` (`fine_amount`, `fine_status`, `id`, `type`, `book_code`, `book_title`) VALUES
(60, 'Unpaid', 104, 'Faculty', 1001, 'Mein Kamf'),
(40, 'Unpaid', 104, 'Faculty', 1004, 'The Secret'),
(180, 'Unpaid', 105, 'Faculty', 1005, 'Think and Grow Rich'),
(40, 'Unpaid', 110, 'Student', 1008, 'Notes from a Small Island'),
(60, 'Unpaid', 115, 'Faculty', 1010, 'The Lord of the Rings');


#JOIN QUERIES

#1. For all faculty who have taken some books, find their last name and the ID.
SELECT distinct last_name, id
FROM members NATURAL JOIN book_issue WHERE type = 'Faculty';

#2. Find all members who have not returned book yet. Display their name ,id, and book name
SELECT members.id,members.first_name, book.book_title
FROM book_issue NATURAL JOIN book NATURAL JOIN members
WHERE book_issue_status = "Not Returned";

#3.Write a Query to display the member id and member name ,type who have minimum fine and show total fine amount and contact number of individual member.
SELECT members.id, 
members.last_name,members_phone_number.phone_number, members.type, 
SUM(fine.fine_amount) AS Total_fine
FROM members NATURAL LEFT OUTER JOIN fine NATURAL LEFT 
OUTER JOIN members_phone_number
WHERE fine.fine_amount>0
GROUP BY (id);

#4. Find the name and number of a member who taken book no 1004.
SELECT members.last_name,book.book_code, book.book_title, 
members_phone_number.phone_number
FROM book NATURAL JOIN book_issue NATURAL JOIN members 
NATURAL LEFT OUTER JOIN members_phone_number
WHERE book.book_code = 1004;

#5. Find all faculty who have taken books, find their last name and the ID.
SELECT distinct members.id, members.last_name
FROM members, book_issue
WHERE members.id = book_issue.id AND members.type = 'Faculty';

#6. Find all the books which are issued by the members who are from Dhaka North and find their last name and id also.
SELECT DISTINCT members.id, members.last_name
FROM members
JOIN book_issue
ON members.id = book_issue.id
WHERE city='Dhaka North';

#7.Write a query to display the author name and his/her book code & name and book quantity have in library. (right outer join)
SELECT author.author_id,author.author_name, book.book_code, book.book_title, 
book.quantity
FROM author NATURAL RIGHT OUTER JOIN book NATURAL RIGHT 
OUTER JOIN has;

#8. Write a query to display the members name, book code of the books which are issued on the date '2021-12-10'
SELECT members.id, members.last_name, book_issue.book_code, 
book_issue.date_issue, book_issue.book_issue_status
FROM members NATURAL JOIN book_issue
WHERE book_issue.date_issue='2021-12-10';

#9.Find an authors published book edition and price.

select author_name,book_edition,price,quantity from author natural join has natural join book where book_title='Rich and Poor';

#Update Queries: 

#1.:Find all the members who returned the book ,update their fine status to Paid (for id:105, book_code: 1005)

UPDATE fine SET fine.fine_status='Paid' where fine.book_code=1005 AND fine.id=105;

select fine.fine_status,fine.book_code, fine.id from fine;

#2.Update phone number for a student who's id is 107
UPDATE members_phone_number SET phone_number = '01787439495' WHERE id = 107;
select id, phone_number from members_phone_number;

#3.Increase the price of the books to 250 which are under 230 and publications from Pyie and Page but they are not in category fictional.

update book SET price=250 WHERE publication='Pyie and Page' and price<230 and category!='Fictional';

select price,publication,category from book;

#4.Update the zip code to 1200 of the Faculty Members who has zip 1221 but they are not in Dhaka North.

UPDATE members SET zip=1200 where zip=1221 AND type='Faculty' AND city!='Dhaka North';
select zip,type,city from members; 

#5.A book is now in demand.Now,update the quantity of a book

UPDATE book SET quantity=quantity+10 where book_title='The Secret' and book_edition='1st Edi.';
select * from book;


#DELETE QUERIES-

#1.Members who paid fine already clear the row
DELETE FROM fine where fine.fine_status='Paid';
select * from fine;

#2. Delete the record of members who has returned the issued books.
DELETE FROM book_issue where book_issue_status='Returned';
select * from book_issue;

#3.Some member returned the book already so there is hardly any need to store that information. So delete that record.

DELETE FROM book_issue where date_returned='2019-12-19';
select * from book_issue;

#VIEW QUERIES-

#Scenario 1: We just want to show our members ID who taken minimum one book from library and if will out book taken list.

CREATE VIEW book_iss
AS SELECT id,book_title, book_issue_status
FROM book_issue;
SELECT* FROM book_iss;

drop view book_iss;

#Scenario 2: We have a scurity isse in our library management system. We do not want to show all of our book information. We will show only Book Name, category, publication and edition.

CREATE VIEW books_have
AS SELECT book_title, category, publication, book_edition
FROM book;

drop view books_have;

select * from books_have;

#Scenario3: Suppose we need to find that which of the members in our library are from Dhaka so that we can give them some sepcial offer. So in that case we need to create a view that shows all the members from Dhaka.

CREATE VIEW specific_member AS
SELECT id, first_name, middle_name, last_name
FROM members
WHERE city = 'Dhaka';

drop view specific_member;

SELECT * FROM specific_member;

#Scenario 4: Suppose we need to find which book's prices are higher than the average price of the books from the library so that we can classify those books as expensive books.So, in that case create a view that selects every book price in the "Book" table with a price higher than the average price

CREATE VIEW higher_than_avg AS
SELECT book_title, price
FROM book
WHERE price > (SELECT AVG(price) FROM book);

drop view higher_than_avg;

select * from higher_than_avg;

#Scenario 5: We have a scurity isse in our library management system. We do not want to show all of our members information. We will show only First name, id, gender.

CREATE VIEW member_info
AS SELECT id, first_name, gender
FROM members;
SELECT * FROM member_info;

drop view member_info;

#Scenario 6: Suppose we need those members list who is Student. Write a query to display the faculty id, faculty name.

CREATE VIEW Student_members AS
SELECT id, first_name
FROM members
WHERE type = 'Student'; 

drop view Student_members;

SELECT * FROM Student_members;  


#------------------------------------------------------------------------------------------------------------------#



















